autok= [
    {
        id:1,
        marka: 'KIA',
        altip: 'CEED',
        szin: {
            szurke: {
                kep: 'kia_ceed_szurke.jpg',
                kiskep: 'szurke_szin.jpg',
                ar: 110000
            },
            bordo: {
                kep: 'kia_ceed_bordo.jpg',
                kiskep: 'bordo_szin.jpg',
                ar: 140000
            },
            kek: {
                kep: 'kia_ceed_kek.jpg',
                kiskep: 'kek_szin.jpg',
                ar: 120000
            },
            feher: {
                kep: 'kia_ceed_feher.jpg',
                kiskep: 'feher_szin.jpg',
                ar: 100000
            }
        },
        szinkulcs: "szurke",
        leiras: '136 Hybrid 48V motorral és DCT váltóval szerelve',
        ar: 8149000,
        belso_felsz: {
	        futheto_ules: {
                ar: 180000,
                Y: true,
                nev: "Fűthető ülés"
            },
            parkolo_radar: {
                ar: 53000,
                Y: false,
                nev: "Parkoló radar"
            },
            tempomat: {
                ar: 230000,
                Y: true,
                nev: "Tempomat"
            },
            biztonsagiov_disz: {
                ar: 3000,
                Y: false,
                nev: "Biztonságiöv dísz"
            }
        }
    },
    {
        id:2,
        marka: 'KIA',
        altip: 'Sorento',
        szin: {
            szurke: {
                kep: 'kia_sorrento_szurke.jpg',
                kiskep: 'szurke_szin.jpg',
                ar: 210000
            },
            bordo: {
                kep: 'kia_sorrento_bordo.jpg',
                kiskep: 'bordo_szin.jpg',
                ar: 240000
            },
            kek: {
                kep: 'kia_sorrento_kek.jpg',
                kiskep: 'kek_szin.jpg',
                ar: 220000
            },
            feher: {
                kep: 'kia_sorrento_feher.jpg',
                kiskep: 'feher_szin.jpg',
                ar: 200000,
            }
        },
        leiras: '136 Hybrid 48V motorral és DCT váltóval szerelve',
        ar: 8149000,
        belso_felsz: {
	        futheto_ules: {
                ar: 210000,
                Y: true,
                nev: "Fűthető ülés"
            },
            parkolo_radar: {
                ar: 91000,
                Y: true,
                nev: "Parkoló radar"
            },
            tempomat: {
                ar: 330000,
                Y: true,
                nev: "Tempomat"
            },
            biztonsagiov_disz: {
                ar: 7000,
                Y: false,
                nev: "Biztonságiöv dísz"
            }
        }
    }

]


// a) irja ki a bordo KIA CEED képének a nevét és árát!
console.log("a) feladat")
for (item of autok){
    if (item.marka == "KIA" && item.altip == "CEED") {
        console.log(item.szin.bordo.kep + " - " + item.szin.bordo.ar + " Ft")
    }
}

// b) irja ki a KIA CEED belso felszereltségnek milyen kulcsai vannak
console.log("b) feladat")
for (item of autok){
    if (item.marka == "KIA" && item.altip == "CEED") {
        for (item2 in item.belso_felsz) {
            console.log(item2)
        }
    }
}


// c) irja ki a kék szinű Sorrentó kép nevét és árát!
console.log("c) feladat")
for (item of autok) {
    if (item.altip == "Sorento") {
        console.log(item.szin.kek.kep + " - " + item.szin.kek.ar)
    }
    
}

// D)  Mennyibe kerül az a KIA CEED amelyik bordó színű és tolatóradart is szereltek bele!
console.log("d) feladat")
for (item of autok) {
    if (item.marka == "KIA" && item.altip == "CEED" && item.belso_felsz.parkolo_radar.Y == true ) {
        console.log(item.bordo.ar)
    }
}


// E)  Mennyibe kerül az a KIA CEED amelyik bordó színű és belső felszereltségnél a  Y: true TRUE!
