/*
var person = {name:"Pista", age:40, email:"pista@email.com"}
 
for (key in person) {
    console.log(key + " = " + person[key])
}
*/


jatekok = [
    {
        id: Math.ceil((new Date()).getTime()+Math.random()*10000),
        nev: 'Bellfaire',
        kep: 'Everdell_Bellfaire.png',
        leiras: '100 év béke és nyugalom, építkezés és gyarapodás, 100 év virágkor az óriás fa árnyékában… A király és a királynő elrendelte az ünnepség megszervezését, amelyen minden erdőlakó részt vehet majd: Everdell fennállásának 100. évfordulóján!',
        kor : '7-99',
        ar: 6500,
    },
    {
        id: Math.ceil((new Date()).getTime()+Math.random()*10000),
        nev: 'Dixit',
        kep: 'dixit.jpg',
        leiras: 'A fantázia és csodás festmények partijátéka. A Dixit világszerte népszerű, Év játéka díjas családi partijáték. A játékosok gyönyörű festménykártyákat kapnak, a „mesélő” kiválaszt egyet a kezéből, amelyről mond egy utalást: egy szót vagy akár egy egész történetet. Majd a többiek is...',
        kor : '10-99',
        ar: 7200,
    },
    {
        id: Math.ceil((new Date()).getTime()+Math.random()*10000),
        nev: 'Arnak elveszett romjai',
        kep: 'aranak.jpg',
        leiras: 'A feltérképezetlen tengerek egyik lakatlan szigetén a felfedezők egy nagy civilizáció nyomaira bukkantak. Te egy expedíciót fogsz most vezetni, hogy felderítsd a szigetet, elveszett ereklyékre lelj és félelmetes őrzőkkel nézz szembe, mindezt azzal a céllal, hogy megismerd a sziget titkait.',
        kor : '8-99',
        ar: 7800,
    }
]

//a) Irja ki a játék nevét és a hozzátartozó kép nevét!
// for copy
for (key in jatekok){
    console.log(jatekok[key].nev + " - " + jatekok[key].kep)
}
// foreach copy
for (key of jatekok){
    console.log(key.nev + " - " + key.kep)
}




telefonok =
	[
		{
			id:1,
			brand: 'Apple',
			name: 'iPhone 14',
			price: 389000,
			picture: 'AppleiPhone14.webp',
			provider: {
				country: 'HU',
				name: 'Vodafone'
			}, 
			katt_db : 0,
			ertekeles_osszeg :0

		},
		{	id:2,
			brand: 'Huawei',
			name: 'Nova9',
			price: 103000,
			picture: 'HuawiNova9.webp',
			provider: {
				country: 'HU',
				name: 'Telekom'
			},
			katt_db : 0,
			ertekeles_osszeg :0
		}
]

//a) irja ki az 1 telefon brand, name, price
for (key of telefonok){
    if (key.id == 1) {
        console.log(key.brand + " " + key.name + " " + key.price)
    }
}


//b) irja ki mindkét telefonra (ciklus)  brand, name, provider name
for (key of telefonok) {
    console.log(key.brand + " " + key.name + " " + key.provider.name)
}


pizza_adatok ={
    meret: {
     m30:{
           kep: 'pizza1.jfif',
         ar: 1200},

     m45:{
         kep: 'pizza2.jfif',
         ar: 1800},

    m50:{
         kep: 'pizza3.jfif',
         ar: 2800},
    },
   sajtok: {
     cedar: {
         ar:300
       },
     trappista: {
         ar:320
       },
     feta: {
         ar:280
       },
       edami : {
         ar:380
       }
   }
}

//a) irja ki a m30-ae pizza képneveét és árát
console.log(pizza_adatok.meret.m30.kep + " " + pizza_adatok.meret.m30.ar)

// b) számitsa ki az árat, ha az m45-ös pizzán  trapista sajt van
console.log(pizza_adatok.meret.m45.ar+pizza_adatok.sajtok.trappista.ar)