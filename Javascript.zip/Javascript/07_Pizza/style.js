pizza_adatok ={
    meret: {
        m30:{
            kep: 'pizza1.jpg',
            ar: 1200},

        m45:{
            kep: 'pizza2.jpg',
            ar: 1800},

        m50:{
            kep: 'pizza3.jpg',
            ar: 2800},
        },
   sajtok: {
     cedar: {
         ar:300
       },
     trappista: {
         ar:320
       },
     feta: {
         ar:280
       },
       edami : {
         ar:380
       }
   }
}

function megjelenites(){
    valasztott = document.getElementById("meret").value
    console.log(valasztott)

    sajt = document.getElementById("sajtok").value
    console.log(sajt)

    aktPizzaar = pizza_adatok.meret[valasztott].ar
    console.log("Választott pizza ára: " + aktPizzaar)

    aktSajtar = pizza_adatok.sajtok[sajt].ar
    console.log("Választott sajt ára: " + aktSajtar)

    atkepNev = pizza_adatok.meret[valasztott].kep

    document.getElementById("kep").innerHTML = `<img src="${atkepNev}">`
    document.getElementById("far").innerHTML = "<h3>Fizetendő összeg: " + (aktPizzaar+aktSajtar) + " Ft</h3>"
}