var gyoztesek = new Array(42);
gyoztesek[1]="Jerzsabek Károly (HUN),22:10:36;Ladányi Gedeon (HUN),+6 p 5 mp;Bouska II. József (HUN),+20 p 33 mp";
gyoztesek[2]="Vida László (HUN),20:05:25;Hölczl Károly (HUN),+13 p 25 mp;Bouska I. (HUN),+13 p 54 mp";
gyoztesek[3]="Vida László (HUN),30:36:17;Huszka Dezső (HUN),+19 p 3 mp;Hugyecz Károly (HUN),+28 p 7 mp";
gyoztesek[4]="Oskar Thierbach (GER),21:31:33;Jálics Béla (HUN),+14 p 20 mp;Istenes János (HUN),+15 p 40 mp";
gyoztesek[5]="Vasco Bergamaschi (ITA),36:29:44;Peck János (HUN),+5 p 20 mp;Minasso (ITA),+25 p 20 mp";
gyoztesek[6]="Liszkay István (HUN),38:10:16;Nemess István (HUN),+32 p 35 mp;Segato (ITA),+34 p 38 mp";
gyoztesek[7]="Vitéz József (HUN),38:01:41;Nemess István (HUN),+1 p 5 mp;Carlotti (ITA),+6 p 58 mp";
gyoztesek[8]="Kurt Stettler (SUI),36:24:22;Martin (SUI),+8 p 17 mp;Orczán László (HUN),+12 p 20 mp";
gyoztesek[9]="Szenes Károly (HUN),33:15:41;Liszkay István (HUN),+1 p 25 mp;Mádl Béla (HUN),+2 p 4 mp";
gyoztesek[10]="Németh Károly (HUN),40:26:37;Éles Ferenc (HUN),+9 p 51 mp;Adorján István (HUN),+10 p  47 mp";
gyoztesek[11]="Anton Strakati (AUT),33:45:23;Wasiliewski (POL),+1 mp;Szalay Antal (HUN),+5 mp";
gyoztesek[12]="Barvik Ferenc (HUN),18:26:29;Gere Gyula (HUN),+2 mp;Irházi Mihály (HUN),+9 mp";
gyoztesek[13]="Liszkay István (HUN),14:44:09;Gere Gyula (HUN),+2 mp;Lakatos (HUN),+2 mp";
gyoztesek[14]="Andre Labeylie (FRA),31:23:33;Lauscha (AUT),+10 p 1 mp;Bourgeteau (FRA),+15 p 2 mp";
gyoztesek[15]="Kis-Dala József (HUN),26:40:41;Bartusek Béla (HUN),+9 p 26 mp;Bencze Márton (HUN),+11 p 36 mp";
gyoztesek[16]="Török Győző (HUN),29:48:11;Albert József (HUN),+4 p 34 mp;Szabó Lajos (HUN),+10 p 32 mp";
gyoztesek[17]="Török Győző (HUN),39:08:03;Károlyi (HUN),+5 p 54 mp;Bende János (HUN),+19 p 13 mp";
gyoztesek[18]="Adolf Christian (AUT),35:22:06;Juszkó János (HUN),+4 p 2 mp;Horváth Ferenc (HUN),+4 p 43 mp";
gyoztesek[19]="Mészáros András (HUN),22:49:58;Höhne (NDK),+20 mp;Juszkó János (HUN),+2 p 54 mp";
gyoztesek[20]="Stámusz Ferenc (HUN),28:18:20;Juhász Béla (HUN),+42 mp;Dévay András (HUN),+1 p 19 mp";
gyoztesek[21]="Mahó László (HUN),23:01:54;Balaskó György (HUN),+1 p 56 mp;Juszkó János (HUN),+3 p 25 mp";
gyoztesek[22]="Jens Dittmann (GER),23:40:58;Kovács Gábor (HUN),+16 mp;Dominique Perras (FRA),+17 mp";
gyoztesek[23]="Wolfgang Kotzmann (AUT),26:42:33;Klimenko (UKR),+1 p 22 mp;Lauk (UKR),+1 p 57 mp";
gyoztesek[24]="Szergej Ivanov (RUS),25:13:28;Kaveckij (BLR),+1 p 54 mp;Jens Dittman (GER),+2 p 13 mp";
gyoztesek[25]="Andrej Tolomanov (UKR),20:09:06;Istlstekker János (HUN),+5 mp;Eisenkrammer Károly (HUN),+15 mp";
gyoztesek[26]="Bebtó Zoltán (HUN),21:28:55;Zajac (UKR),+10 mp;Rohtmer Balázs (HUN),+12 mp";
gyoztesek[27]="Alekszandr Rotar (UKR),27:16:24;Nazarenko (UKR),+51 mp;Eisenkrammer Károly (HUN),+1 p 25 mp";
gyoztesek[28]="Mikos Rnyakovics (YUG),14:26:18;Nagy Róbert (SVK),+23 mp;Bronis (SVK),+23 mp";
gyoztesek[29]="Vanik Zoltán (HUN),14:31:23;Faltynek (CZE),+15 mp;Blahut (CZE),+17 mp";
gyoztesek[30]="Remák Zoltán (SVK),19:57:54;Jurco (SVK),+1 p 4 mp;Sowinski (POL),+3 p 1 mp";
gyoztesek[31]="Remák Zoltán (SVK),20:03:26;Phillip Thuaux (AUS),+2 p 6 mp;Martin Prazdnovsky (SVK),+2 p 23 mp";
gyoztesek[32]="Lengyel Tamás (HUN),16:52:23;Martin Prazdnovsky (SVK),+45 mp;Glen Chadwick (AUS),+1 p 53 mp";
gyoztesek[33]="Martin Riska (CZE),14:03:54;Remák Zoltán (SVK),+25 mp;Szekeres Csaba (HUN),+3 p 8 mp";
gyoztesek[34]="Andrew Bradley (AUT),20:17:19;Miroslav Keliar (SVK),+3 p 0 mp;Stefan Pöll (AUT),+3 p 6 mp";
gyoztesek[35]="Hans Bloks (NED),20:29:22;Vladimir Kerkez (SLO),+16 mp;Ivan Stevic (SRB),+34 mp";
gyoztesek[36]="Tom Thill (LUX),15:31:02;Andi Bajc (SLO),+44 mp;James Early (NZL),+1 p 51 mp";
gyoztesek[37]="Mihkel Raim (EST),16:34:50;Oleksandr Polivoda (UKR),+18 mp;Daniel Turek (CZE),+20 mp";
gyoztesek[38]="Daniel Jaramillo (COL),13:53:43;Peák Barnabás (HUN),+2 mp;Tadej Pogacar (SLO),+7 mp";
gyoztesek[39]="Manuel Belletti (ITA),19:21:07;Kamil Malecki (POL),+7 mp;Paolo Toto (ITA),+8 mp";
gyoztesek[40]="Krists Neilands (LAT),21:12:00;Dina Márton (HUN),+1 p 22 mp;Valter Attila (HUN),+1 p 26 mp";
gyoztesek[41]="Valter Attila (HUN),18:45:55;Simmons Quinn (USA),+12 mp;Howson Damien (AUS),+16 mp";

function listaelem(eredmeny){
  if (eredmeny.includes("(HUN)")) {
    return "<b>"+eredmeny.replace(",","<br>")+"</b>";
  } 
  else
  {
    return eredmeny.replace(",","<br>");
  }
}

function frissit(){
    var sorsz = document.getElementById('verseny').value;
    document.getElementById('hely1').innerHTML = listaelem(gyoztesek[sorsz].split(";")[0]); 
    document.getElementById('hely2').innerHTML = listaelem(gyoztesek[sorsz].split(";")[1]); 
    document.getElementById('hely3').innerHTML = listaelem(gyoztesek[sorsz].split(";")[2]);
    document.getElementById('sorszam').innerHTML = sorsz
}
