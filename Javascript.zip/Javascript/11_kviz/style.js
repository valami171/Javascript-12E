function kiertekel(){
    for (let i = 0; i < array.length; i++) {
        
        
    }
}