

korokDb = Math.floor(Math.random()*65+5)

for (let i = 0; i < korokDb; i++) {
    newDiv = document.createElement("div");
    // pozició
    pozx = Math.floor(Math.random()*1000)
    pozy = Math.floor(Math.random()*700)
    newDiv.style.top = pozy+"px"
    newDiv.style.left = pozx+"px"
    // méret
    meret = Math.floor(Math.random()*90+10)
    newDiv.style.width = meret+"px"
    newDiv.style.height = meret+"px"
    // szín
    newDiv.style.backgroundColor = `rgb(${Math.floor(Math.random()*256)},${Math.floor(Math.random()*256)},${Math.floor(Math.random()*256)})`;
    document.body.appendChild(newDiv);
}


