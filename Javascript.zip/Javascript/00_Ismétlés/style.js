szam1 = Number(document.getElementById("szam1").value)
szam2 = Number(document.getElementById("szam2").value)


function osszeadas(){
    osszeg = szam1+szam2
    document.getElementById('eredmeny').innerHTML = osszeg
}